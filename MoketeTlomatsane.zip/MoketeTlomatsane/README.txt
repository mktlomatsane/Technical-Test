1.Framework used is Selenium and Eclipse
2.Manual Test cases on the excel name Ezye test case
3.Main project(Eclipse automated) attached named LoginEzye
4. Selenium test cases attached named 'login page test', 'Medical History form edit' and 'Techstudy fields Tests'

Mokete Kinsly Tlomatsane