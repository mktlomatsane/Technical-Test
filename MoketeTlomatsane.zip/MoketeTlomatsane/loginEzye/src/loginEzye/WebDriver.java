package loginEzye;

public class WebDriver {

	public Object manage() {
		// TODO Auto-generated method stub
		return null;
	}

}
