


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;

;

import java.util.*;
import java.net.MalformedURLException;
import java.net.URL;
public class SeleniumEzyeLogin {
  public WebDriver driver;

  public SeleniumEzyeLogin() {
	  
	 System.setProperty("webdriver.chrome.driver", "C:\Users\KINGSLEY\Downloads\Foremix\chromedriver_win32\chromedriver.exe"); 
	  
    driver = new ChromeDriver();
    
    driver.get("https://ryze-staging.formedix.com/sign-in");
    driver.manage().window().setSize(new Dimension(792, 814));
    driver.findElement(By.id("username")).sendKeys("testteamtechtest");
    driver.findElement(By.id("password")).click();
    driver.findElement(By.id("password")).sendKeys("T3cht3ster");
    driver.findElement(By.id("btnSubmit")).click();
  }
}
 
 
