package loginEzye;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;

import java.util.*;
import java.net.MalformedURLException;
import java.net.URL;
public class TechStudy {
private WebDriver driver;

public void setUp() {
	 System.setProperty("webdriver.chrome.driver", "C:\Users\KINGSLEY\Downloads\Foremix\chromedriver_win32\chromedriver.exe"); 
	  
 driver = new ChromeDriver();
 
}


public void verifyingthethreebartabfunctionality() {
 driver.get("https://ryze-staging.formedix.com/sign-in");
 driver.manage().window().setSize(new Dimension(792, 814));
 driver.findElement(By.id("btnSubmit")).click();
 driver.findElement(By.cssSelector(".fdx-main-nav-item > .fdx-repository")).click();
 driver.findElement(By.cssSelector("#menuMdbStudies .fdx-sub-nav-menu-item-label")).click();
 driver.findElement(By.id("fdxMdbContainerListItem0MenuToggle")).click();
 driver.findElement(By.id("fdxMdbContainerListItem0View")).click();
 driver.findElement(By.id("ViewAssetGroupdataAcquisition")).click();
 driver.findElement(By.id("FORMTypeView")).click();
}
}
