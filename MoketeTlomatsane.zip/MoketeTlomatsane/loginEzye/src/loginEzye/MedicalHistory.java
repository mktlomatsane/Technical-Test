package loginEzye;


import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.core.IsNot.not;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.JavascriptExecutor;
import java.util.*;
import java.net.MalformedURLException;
import java.net.URL;
public class MedicalHistory {
private WebDriver driver;

public void setUp() {
	ystem.setProperty("webdriver.chrome.driver", "C:\Users\KINGSLEY\Downloads\Foremix\chromedriver_win32\chromedriver.exe"); 
	  
 driver = new ChromeDriver();

}

public void medicalHistory() {
 driver.get("https://ryze-staging.formedix.com/sign-in");
 driver.manage().window().setSize(new Dimension(792, 814));
 driver.findElement(By.id("btnSubmit")).click();
 driver.findElement(By.cssSelector("#menuMdb .fdx-main-nav-item-label")).click();
 driver.findElement(By.cssSelector("#menuMdbStudies .fdx-sub-nav-menu-item-desc")).click();
 driver.findElement(By.id("fdxMdbContainerListItem0MenuToggle")).click();
 driver.findElement(By.id("fdxMdbContainerListItem0View")).click();
 {
   WebElement element = driver.findElement(By.id("ViewAssetGroupdataAcquisition"));
   Actions builder = new Actions(driver);
   builder.moveToElement(element).perform();
 }
 driver.findElement(By.id("ViewAssetGroupdataAcquisition")).click();
 driver.findElement(By.id("FORMTypeView")).click();
 driver.findElement(By.cssSelector("#uuid-bafcf34b-2ce6-4a8d-b4be-58c25e481b47 .fdx-ellipsis:nth-child(1)")).click();
 driver.findElement(By.id("switchEditMode")).click();
 {
   WebElement element = driver.findElement(By.id("switchEditMode"));
   Actions builder = new Actions(driver);
   builder.moveToElement(element).perform();
 }
 {
   WebElement element = driver.findElement(By.tagName("body"));
   Actions builder = new Actions(driver);
   builder.moveToElement(element, 0, 0).perform();
 }
 driver.findElement(By.cssSelector("#AssetEditViewRowdescription > .col-md-4")).click();
 driver.findElement(By.cssSelector("#editPropsAddEntrydescription > .add-btn-text")).click();
 driver.findElement(By.id("overview-form")).click();
 driver.findElement(By.id("saveAsset")).click();
}
}
