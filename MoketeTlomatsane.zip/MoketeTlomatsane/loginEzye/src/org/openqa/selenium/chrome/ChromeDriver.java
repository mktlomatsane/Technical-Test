package org.openqa.selenium.chrome;

public record ChromeDriver() {

}
