module loginEzye {
	requires selenium.chrome.driver;
	requires selenium.api;
}