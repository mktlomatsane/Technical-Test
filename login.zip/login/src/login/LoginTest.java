package login;

import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;




public class LoginTest {
	
	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver", "C:\\chromedriver_win32\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		
		driver.get("https://ryze-staging.formedix.com/sign-in");
	    driver.manage().window().setSize(new Dimension(792, 814));
	    driver.findElement(By.id("username")).sendKeys("testteamtechtest");
	    driver.findElement(By.id("password")).click();
	    driver.findElement(By.id("password")).sendKeys("T3cht3ster");
	    driver.findElement(By.id("btnSubmit")).click();
	   String u=driver.getCurrentUrl();
	    
	    if(u.equals("https://ryze-staging.formedix.com/sign-in")) {
	    	System.out.print("passed") ;
	    }
	    else
	    	System.out.print("passed") ;

	  }
	

		
	}


